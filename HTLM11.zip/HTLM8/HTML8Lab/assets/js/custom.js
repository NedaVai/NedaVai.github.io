// assets/js/custom.js

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");

  // REAL-TIME VALIDATION RULES
function validateName(value) {
  return /^[A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž\s-]+$/.test(value);
}

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function validateAddress(value) {
  return value.trim().length > 0;
}

function showInputError(input, messageElement, message) {
  input.classList.add("input-error");
  messageElement.textContent = message;
}

function clearInputError(input, messageElement) {
  input.classList.remove("input-error");
  messageElement.textContent = "";
}

  // Laukai
  const firstNameInput = document.getElementById("first-name");
  const lastNameInput = document.getElementById("last-name");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");
  const addressInput = document.getElementById("address");

  const q1Input = document.getElementById("q1");
  const q2Input = document.getElementById("q2");
  const q3Input = document.getElementById("q3");

  const q1Value = document.getElementById("q1-value");
  const q2Value = document.getElementById("q2-value");
  const q3Value = document.getElementById("q3-value");

  // Attach real-time validators
firstNameInput.addEventListener("input", () => {
  const msg = document.getElementById("error-first-name");
  if (!validateName(firstNameInput.value)) {
    showInputError(firstNameInput, msg, "Vardas gali būti sudarytas tik iš raidžių.");
  } else {
    clearInputError(firstNameInput, msg);
  }
  validateFormState();
});

lastNameInput.addEventListener("input", () => {
  const msg = document.getElementById("error-last-name");
  if (!validateName(lastNameInput.value)) {
    showInputError(lastNameInput, msg, "Pavardė gali būti sudaryta tik iš raidžių.");
  } else {
    clearInputError(lastNameInput, msg);
  }
  validateFormState();
});

emailInput.addEventListener("input", () => {
  const msg = document.getElementById("error-email");
  if (!validateEmail(emailInput.value)) {
    showInputError(emailInput, msg, "Įveskite teisingą el. pašto adresą.");
  } else {
    clearInputError(emailInput, msg);
  }
  validateFormState();
});

addressInput.addEventListener("input", () => {
  const msg = document.getElementById("error-address");
  if (!validateAddress(addressInput.value)) {
    showInputError(addressInput, msg, "Adresas negali būti tuščias.");
  } else {
    clearInputError(addressInput, msg);
  }
  validateFormState();
});

// Phone format

// Remove everything except digits
function cleanDigits(str) {
  return str.replace(/\D/g, "");
}

phoneInput.addEventListener("input", () => {
  let digits = cleanDigits(phoneInput.value);

  // Restrict to Lithuanian phone length (11 digits after +370)
  if (digits.startsWith("370")) {
    digits = digits.substring(3); // remove 370 prefix
  }

  // Restrict to max 8 digits after +3706...
  digits = digits.substring(0, 8);

  // Build formatted number
  let formatted = "+370 ";

  if (digits.length > 0) {
    formatted += digits.substring(0, 1); // "6"
  }
  if (digits.length > 1) {
    formatted += digits.substring(1, 3); // "xx"
  }
  if (digits.length > 3) {
    formatted += " " + digits.substring(3); // "xxxxx"
  }

  phoneInput.value = formatted;

  // Real-time error display
  const msg = document.getElementById("error-phone");

  if (!/^\+370 6\d{2} \d{5}$/.test(formatted)) {
    phoneInput.classList.add("input-error");
    msg.textContent = "Telefono numeris turi būti formato +370 6xx xxxxx";
  } else {
    phoneInput.classList.remove("input-error");
    msg.textContent = "";
  }
  validateFormState(); // update submit button
});

  // SUBMIT BUTTON ENABLE LOGIC

  function validateFormState() {
    const hasErrors =
      document.querySelectorAll(".input-error").length > 0 ||
      !firstNameInput.value.trim() ||
      !lastNameInput.value.trim() ||
      !emailInput.value.trim() ||
      !addressInput.value.trim() ||
      !phoneInput.value.trim();

    const submitBtn = document.getElementById("submit-btn");

    submitBtn.disabled = hasErrors;
  }

  // Pranešimų elementai
  const loadingEl = document.querySelector(".loading");
  const errorMessageEl = document.querySelector(".error-message");
  const sentMessageEl = document.querySelector(".sent-message");

  // Pagalbinės funkcijos pranešimams
  function showLoading() {
    loadingEl.style.display = "block";
    errorMessageEl.style.display = "none";
    sentMessageEl.style.display = "none";
  }

  function showError(message) {
    loadingEl.style.display = "none";
    errorMessageEl.style.display = "block";
    errorMessageEl.textContent = message;
    sentMessageEl.style.display = "none";
  }

  function showSuccess(message) {
    loadingEl.style.display = "none";
    errorMessageEl.style.display = "none";
    sentMessageEl.style.display = "block";
    sentMessageEl.textContent = message;
  }

  // Sliderių reikšmės atvaizdavimas
  function initSlider(input, outputSpan) {
    if (!input || !outputSpan) return;

    // pradinė reikšmė
    outputSpan.textContent = input.value;

    input.addEventListener("input", function () {
      outputSpan.textContent = input.value;
    });
  }

  initSlider(q1Input, q1Value);
  initSlider(q2Input, q2Value);
  initSlider(q3Input, q3Value);

  // Paprasta el. pašto validacija
  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }

  // Paprasta telefono validacija (tik skaičiai, +, tarpai, max ilgis)
  function isValidPhone(phone) {
    const cleaned = phone.replace(/[\s\-]/g, "");
    const re = /^\+?[0-9]{6,15}$/;
    return re.test(cleaned);
  }

  // Sliderių validacija 1–10 (šiaip range jau riboja, bet tikriname ir JS)
  function isValidRating(value) {
    const num = Number(value);
    return num >= 1 && num <= 10;
  }

  // Formos pateikimas
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // neleidžiam numatyto elgesio (puslapio perkrovimo)

    showLoading();

    // Pagrindinė validacija
    const firstName = firstNameInput.value.trim();
    const lastName = lastNameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    const address = addressInput.value.trim();

    const rating1 = q1Input.value;
    const rating2 = q2Input.value;
    const rating3 = q3Input.value;

    // 1. Ar visi būtini laukai užpildyti?
    if (!firstName || !lastName || !email || !phone || !address) {
      showError("Prašome užpildyti visus privalomus laukus.");
      return;
    }

    // 2. El. paštas
    if (!isValidEmail(email)) {
      showError("Prašome įvesti teisingą el. pašto adresą.");
      return;
    }

    // 3. Telefonas
    if (!isValidPhone(phone)) {
      showError("Prašome įvesti teisingą telefono numerį (tik skaičiai ir galimas +).");
      return;
    }

    // 4. Vertinimo reikšmės
    if (!isValidRating(rating1) || !isValidRating(rating2) || !isValidRating(rating3)) {
      showError("Vertinimo klausimų reikšmės turi būti tarp 1 ir 10.");
      return;
    }

    // Prepare form data object
    const formData = {
    first_name: firstName,
    last_name: lastName,
    email: email,
    phone: phone,
    address: address,
    rating_design: rating1,
    rating_usability: rating2,
    rating_overall: rating3
    };

    // 5. AVERAGE OF RATINGS
    const avg = ((Number(rating1) + Number(rating2) + Number(rating3)) / 3).toFixed(1);

    // Display average under results
    const avgBox = document.getElementById("rating-average");
    avgBox.textContent = `${firstName} ${lastName}: ${avg}`;


    // (i) Console log the data
    console.log("Siunčiami duomenys:", formData);

    // (ii) Display results on the page
    const resultsBox = document.getElementById("form-results");
    const resultsOutput = document.getElementById("results-output");

    resultsBox.style.display = "block";
    resultsOutput.textContent = JSON.stringify(formData, null, 2);

        // Show success message
    showSuccess("Jūsų forma sėkmingai išsiųsta. Ačiū!");

    // ⭐ SUCCESS POP-UP ⭐
    const popup = document.getElementById("success-popup");
    popup.style.display = "block";

    setTimeout(() => {
      popup.style.display = "none";
    }, 2500);

    // Reset slider values to default
    q1Input.value = 5;
    q2Input.value = 5;
    q3Input.value = 5;
    q1Value.textContent = 5;
    q2Value.textContent = 5;
    q3Value.textContent = 5;

  });
});
