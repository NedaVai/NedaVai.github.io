// assets/js/custom.js

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");

  // REAL-TIME VALIDATION RULES
function validateName(value) {
  return /^[A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž\s-]+$/.test(value);
}

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function validateAddress(value) {
  return value.trim().length > 0;
}

function showInputError(input, messageElement, message) {
  input.classList.add("input-error");
  messageElement.textContent = message;
}

function clearInputError(input, messageElement) {
  input.classList.remove("input-error");
  messageElement.textContent = "";
}

  // Laukai
  const firstNameInput = document.getElementById("first-name");
  const lastNameInput = document.getElementById("last-name");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");
  const addressInput = document.getElementById("address");

  const q1Input = document.getElementById("q1");
  const q2Input = document.getElementById("q2");
  const q3Input = document.getElementById("q3");

  const q1Value = document.getElementById("q1-value");
  const q2Value = document.getElementById("q2-value");
  const q3Value = document.getElementById("q3-value");

  // Attach real-time validators
firstNameInput.addEventListener("input", () => {
  const msg = document.getElementById("error-first-name");
  if (!validateName(firstNameInput.value)) {
    showInputError(firstNameInput, msg, "Vardas gali būti sudarytas tik iš raidžių.");
  } else {
    clearInputError(firstNameInput, msg);
  }
  validateFormState();
});

lastNameInput.addEventListener("input", () => {
  const msg = document.getElementById("error-last-name");
  if (!validateName(lastNameInput.value)) {
    showInputError(lastNameInput, msg, "Pavardė gali būti sudaryta tik iš raidžių.");
  } else {
    clearInputError(lastNameInput, msg);
  }
  validateFormState();
});

emailInput.addEventListener("input", () => {
  const msg = document.getElementById("error-email");
  if (!validateEmail(emailInput.value)) {
    showInputError(emailInput, msg, "Įveskite teisingą el. pašto adresą.");
  } else {
    clearInputError(emailInput, msg);
  }
  validateFormState();
});

addressInput.addEventListener("input", () => {
  const msg = document.getElementById("error-address");
  if (!validateAddress(addressInput.value)) {
    showInputError(addressInput, msg, "Adresas negali būti tuščias.");
  } else {
    clearInputError(addressInput, msg);
  }
  validateFormState();
});

// Phone format

// Remove everything except digits
function cleanDigits(str) {
  return str.replace(/\D/g, "");
}

phoneInput.addEventListener("input", () => {
  let digits = cleanDigits(phoneInput.value);

  // Restrict to Lithuanian phone length (11 digits after +370)
  if (digits.startsWith("370")) {
    digits = digits.substring(3); // remove 370 prefix
  }

  // Restrict to max 8 digits after +3706...
  digits = digits.substring(0, 8);

  // Build formatted number
  let formatted = "+370 ";

  if (digits.length > 0) {
    formatted += digits.substring(0, 1); // "6"
  }
  if (digits.length > 1) {
    formatted += digits.substring(1, 3); // "xx"
  }
  if (digits.length > 3) {
    formatted += " " + digits.substring(3); // "xxxxx"
  }

  phoneInput.value = formatted;

  // Real-time error display
  const msg = document.getElementById("error-phone");

  if (!/^\+370 6\d{2} \d{5}$/.test(formatted)) {
    phoneInput.classList.add("input-error");
    msg.textContent = "Telefono numeris turi būti formato +370 6xx xxxxx";
  } else {
    phoneInput.classList.remove("input-error");
    msg.textContent = "";
  }
  validateFormState(); // update submit button
});

  // SUBMIT BUTTON ENABLE LOGIC

  function validateFormState() {
    const hasErrors =
      document.querySelectorAll(".input-error").length > 0 ||
      !firstNameInput.value.trim() ||
      !lastNameInput.value.trim() ||
      !emailInput.value.trim() ||
      !addressInput.value.trim() ||
      !phoneInput.value.trim();

    const submitBtn = document.getElementById("submit-btn");

    submitBtn.disabled = hasErrors;
  }

  // Pranešimų elementai
  const loadingEl = document.querySelector(".loading");
  const errorMessageEl = document.querySelector(".error-message");
  const sentMessageEl = document.querySelector(".sent-message");

  // Pagalbinės funkcijos pranešimams
  function showLoading() {
    loadingEl.style.display = "block";
    errorMessageEl.style.display = "none";
    sentMessageEl.style.display = "none";
  }

  function showError(message) {
    loadingEl.style.display = "none";
    errorMessageEl.style.display = "block";
    errorMessageEl.textContent = message;
    sentMessageEl.style.display = "none";
  }

  function showSuccess(message) {
    loadingEl.style.display = "none";
    errorMessageEl.style.display = "none";
    sentMessageEl.style.display = "block";
    sentMessageEl.textContent = message;
  }

  // Sliderių reikšmės atvaizdavimas
  function initSlider(input, outputSpan) {
    if (!input || !outputSpan) return;

    // pradinė reikšmė
    outputSpan.textContent = input.value;

    input.addEventListener("input", function () {
      outputSpan.textContent = input.value;
    });
  }

  initSlider(q1Input, q1Value);
  initSlider(q2Input, q2Value);
  initSlider(q3Input, q3Value);

  // Paprasta el. pašto validacija
  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }

  // Paprasta telefono validacija (tik skaičiai, +, tarpai, max ilgis)
  function isValidPhone(phone) {
    const cleaned = phone.replace(/[\s\-]/g, "");
    const re = /^\+?[0-9]{6,15}$/;
    return re.test(cleaned);
  }

  // Sliderių validacija 1–10 (šiaip range jau riboja, bet tikriname ir JS)
  function isValidRating(value) {
    const num = Number(value);
    return num >= 1 && num <= 10;
  }

  // Formos pateikimas
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // neleidžiam numatyto elgesio (puslapio perkrovimo)

    showLoading();

    // Pagrindinė validacija
    const firstName = firstNameInput.value.trim();
    const lastName = lastNameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    const address = addressInput.value.trim();

    const rating1 = q1Input.value;
    const rating2 = q2Input.value;
    const rating3 = q3Input.value;

    // 1. Ar visi būtini laukai užpildyti?
    if (!firstName || !lastName || !email || !phone || !address) {
      showError("Prašome užpildyti visus privalomus laukus.");
      return;
    }

    // 2. El. paštas
    if (!isValidEmail(email)) {
      showError("Prašome įvesti teisingą el. pašto adresą.");
      return;
    }

    // 3. Telefonas
    if (!isValidPhone(phone)) {
      showError("Prašome įvesti teisingą telefono numerį (tik skaičiai ir galimas +).");
      return;
    }

    // 4. Vertinimo reikšmės
    if (!isValidRating(rating1) || !isValidRating(rating2) || !isValidRating(rating3)) {
      showError("Vertinimo klausimų reikšmės turi būti tarp 1 ir 10.");
      return;
    }

    // Prepare form data object
    const formData = {
    first_name: firstName,
    last_name: lastName,
    email: email,
    phone: phone,
    address: address,
    rating_design: rating1,
    rating_usability: rating2,
    rating_overall: rating3
    };

    // 5. AVERAGE OF RATINGS
    const avg = ((Number(rating1) + Number(rating2) + Number(rating3)) / 3).toFixed(1);

    // Display average under results
    const avgBox = document.getElementById("rating-average");
    avgBox.textContent = `${firstName} ${lastName}: ${avg}`;


    // (i) Console log the data
    console.log("Siunčiami duomenys:", formData);

    // (ii) Display results on the page
    const resultsBox = document.getElementById("form-results");
    const resultsOutput = document.getElementById("results-output");

    resultsBox.style.display = "block";
    resultsOutput.textContent = JSON.stringify(formData, null, 2);

        // Show success message
    showSuccess("Jūsų forma sėkmingai išsiųsta. Ačiū!");

    // ⭐ SUCCESS POP-UP ⭐
    const popup = document.getElementById("success-popup");
    popup.style.display = "block";

    setTimeout(() => {
      popup.style.display = "none";
    }, 2500);

    // Reset slider values to default
    q1Input.value = 5;
    q2Input.value = 5;
    q3Input.value = 5;
    q1Value.textContent = 5;
    q2Value.textContent = 5;
    q3Value.textContent = 5;

      // ==========================
  

  });

  // ==========================
  // MANO ŽAIDIMAS
  // ==========================

  const baseCardSymbols = [
    "🍀", "🚀", "🎧", "📚", "🎮", "💡",
    "🌙", "☕", "🎲", "📷", "🎹", "🌈"
  ];

  const gameBoard        = document.getElementById("game-board");
  const difficultySelect = document.getElementById("difficulty");
  const movesCountEl     = document.getElementById("moves-count");
  const pairsCountEl     = document.getElementById("pairs-count");
  const winMessageEl     = document.getElementById("win-message");
  const startGameBtn     = document.getElementById("start-game");
  const resetGameBtn     = document.getElementById("reset-game");

  const bestEasyEl       = document.getElementById("best-easy");
  const bestHardEl       = document.getElementById("best-hard");
  const timerEl          = document.getElementById("game-timer");

  if (gameBoard && difficultySelect) {

    // Žaidimo būsena
    let firstCard    = null;
    let secondCard   = null;
    let lockBoard    = false;
    let moves        = 0;
    let matchedPairs = 0;
    let totalPairs   = 0;

    // Laikmatis
    let timerInterval = null;
    let elapsedSeconds = 0;

    // Rekordai
    let bestMovesEasy = null;
    let bestMovesHard = null;

    const LS_KEYS = {
      easy: "memoryBest_easy",
      hard: "memoryBest_hard"
    };

    // -----------------------------
    // Laikmatis
    // -----------------------------

    function formatTime(seconds) {
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
    }

    function updateTimerDisplay() {
      if (timerEl) {
        timerEl.textContent = formatTime(elapsedSeconds);
      }
    }

    function startTimer() {
      // pradėti nuo nulio
      if (timerInterval) clearInterval(timerInterval);
      elapsedSeconds = 0;
      updateTimerDisplay();

      timerInterval = setInterval(() => {
        elapsedSeconds++;
        updateTimerDisplay();
      }, 1000);
    }

    function stopTimer() {
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
      }
    }

    // -----------------------------
    // Rekordai (localStorage)
    // -----------------------------

    function updateBestUI() {
      bestEasyEl.textContent = bestMovesEasy !== null ? bestMovesEasy : "–";
      bestHardEl.textContent = bestMovesHard !== null ? bestMovesHard : "–";
    }

    function loadBestScores() {
      const easyVal = localStorage.getItem(LS_KEYS.easy);
      const hardVal = localStorage.getItem(LS_KEYS.hard);

      bestMovesEasy = easyVal !== null ? Number(easyVal) : null;
      bestMovesHard = hardVal !== null ? Number(hardVal) : null;

      if (Number.isNaN(bestMovesEasy)) bestMovesEasy = null;
      if (Number.isNaN(bestMovesHard)) bestMovesHard = null;

      updateBestUI();
    }

    function maybeUpdateBestScore(difficulty, currentMoves) {
      if (difficulty === "hard") {
        if (bestMovesHard === null || currentMoves < bestMovesHard) {
          bestMovesHard = currentMoves;
          localStorage.setItem(LS_KEYS.hard, String(currentMoves));
        }
      } else {
        // easy (ir viskas, kas ne "hard")
        if (bestMovesEasy === null || currentMoves < bestMovesEasy) {
          bestMovesEasy = currentMoves;
          localStorage.setItem(LS_KEYS.easy, String(currentMoves));
        }
      }

      updateBestUI();
    }

    // -----------------------------
    // Žaidimo konfiguracija ir būsena
    // -----------------------------

    function getConfigForDifficulty() {
      const difficulty = difficultySelect.value;

      if (difficulty === "hard") {
        // 6 × 4 = 24 kortos = 12 porų
        return { pairs: 12, columns: 6 };
      }
      // easy – 4 × 3 = 12 kortų = 6 porų
      return { pairs: 6, columns: 4 };
    }

    function resetGameState() {
      firstCard    = null;
      secondCard   = null;
      lockBoard    = false;
      moves        = 0;
      matchedPairs = 0;

      if (movesCountEl) movesCountEl.textContent = "0";
      if (pairsCountEl) pairsCountEl.textContent = "0";
      if (winMessageEl) winMessageEl.textContent = "";
    }

    function generateCardData() {
      const cfg = getConfigForDifficulty();

      totalPairs = cfg.pairs;

      const chosenSymbols = baseCardSymbols.slice(0, cfg.pairs);
      const cards = [...chosenSymbols, ...chosenSymbols];

      // Fisher–Yates maišymas
      for (let i = cards.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cards[i], cards[j]] = [cards[j], cards[i]];
      }

      return { cards, columns: cfg.columns };
    }

    function createCardElement(symbol, index) {
      const card = document.createElement("button");
      card.type = "button";
      card.classList.add("game-card", "hidden");

      card.dataset.symbol = symbol;
      card.dataset.index  = index;
      card.textContent    = symbol;

      card.addEventListener("click", function () {
        handleCardClick(card);
      });

      return card;
    }

    function handleCardClick(card) {
      if (lockBoard) return;
      if (card.classList.contains("flipped") || card.classList.contains("matched")) return;

      card.classList.remove("hidden");
      card.classList.add("flipped");

      if (!firstCard) {
        firstCard = card;
        return;
      }

      secondCard = card;
      lockBoard  = true;

      moves++;
      if (movesCountEl) movesCountEl.textContent = moves;

      const isMatch = firstCard.dataset.symbol === secondCard.dataset.symbol;

      if (isMatch) {
        // sutapo
        firstCard.classList.add("matched");
        secondCard.classList.add("matched");

        matchedPairs++;
        if (pairsCountEl) pairsCountEl.textContent = matchedPairs;

        // Ar tai paskutinė pora?
        if (matchedPairs === totalPairs) {
          // sustabdom laikmatį
          stopTimer();

          const difficulty = difficultySelect.value;
          if (winMessageEl) {
            winMessageEl.textContent = `Laimėjote! Visi porų rinkiniai rasti per ${moves} ėjimus, per ${formatTime(elapsedSeconds)}.`;
          }

          // 1.b – palyginam ir, jei geriau, atnaujinam localStorage + UI
          maybeUpdateBestScore(difficulty, moves);
        }

        resetTurn();
      } else {
        // nesutapo – užverčiam po 1s
        setTimeout(() => {
          firstCard.classList.remove("flipped");
          secondCard.classList.remove("flipped");

          firstCard.classList.add("hidden");
          secondCard.classList.add("hidden");

          resetTurn();
        }, 1000);
      }
    }

    function resetTurn() {
      firstCard  = null;
      secondCard = null;
      lockBoard  = false;
    }

    function renderGameBoard() {
      resetGameState();

      const { cards, columns } = generateCardData();

      gameBoard.style.display = "grid";
      gameBoard.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
      gameBoard.innerHTML = "";

      cards.forEach((symbol, index) => {
        const cardEl = createCardElement(symbol, index);
        gameBoard.appendChild(cardEl);
      });
    }

    function startNewGame() {
      // 2 – laikmatis turi startuoti tik nuo Start / naujo žaidimo
      stopTimer();
      renderGameBoard();
      startTimer();
    }

    // Mygtukai
    if (startGameBtn) {
      startGameBtn.addEventListener("click", startNewGame);
    }

    if (resetGameBtn) {
      resetGameBtn.addEventListener("click", startNewGame);
    }

    // Keičiant sudėtingumą – naujas žaidimas ir naujas laikmatis
    difficultySelect.addEventListener("change", startNewGame);

    // 1.a – užkraunam geriausius rezultatus iš localStorage, kai atsidaro puslapis
    loadBestScores();

    // Svarbu: čia NEkviečiam startNewGame(),
    // kad žaidimas ir laikmatis neprasidėtų be mygtuko "Start".
  }



});
